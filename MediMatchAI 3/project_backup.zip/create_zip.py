
import os
import zipfile

def zip_project():
    zip_name = 'project_backup.zip'
    with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk('.'):
            if '.git' in dirs:
                dirs.remove('.git')  # Skip git directory
            if '__pycache__' in dirs:
                dirs.remove('__pycache__')  # Skip cache directories
            for file in files:
                if file != zip_name:  # Don't include the zip file itself
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, '.')
                    zipf.write(file_path, arcname)
    
    print(f"Project has been zipped to {zip_name}")

if __name__ == "__main__":
    zip_project()
